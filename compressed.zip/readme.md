![octofiles](https://user-images.githubusercontent.com/459713/53930194-77a64680-405e-11e9-870c-f0f15d039230.png)

# octofiles

> Easily upload files to GitHub via Chrome Extension
